package com.example.pokemon_cartas;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

//Raul Antonio Serra

public class MainActivity extends AppCompatActivity {
    //variables basicas
    ImageButton imb00,imb01,imb02,imb03,imb04,imb05,imb06,imb07,imb08,imb09,imb10,imb11;
    ImageButton[] listaBotones=new ImageButton[12];
    int aciertos;
    int [] imagenes;
    int puntuacion;
    String punt;

    //Variables para reorganizar
    ArrayList<Integer> arrayDesordenar;
    ImageButton primero;
    int numPrimero,numSegundo;
    boolean bloqueo=false;
    final Handler handler=new Handler();
    //Variables adicionales
    MediaPlayer mediaPlayer;
    TextView pnt;

    //Solo restara puntuacion al reiniciar la aplicacion ya que entendemos puntuacion como
    //las parejas que tenemos correctas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer = MediaPlayer.create(this, R.raw.flip_card);
        puntuacion=0;
        init();
        pnt=findViewById(R.id.textViewPuntuacion);
    }

    private void Juego(){
        imb00= findViewById(R.id.imageButton1);
        imb01= findViewById(R.id.imageButton2);
        imb02= findViewById(R.id.imageButton3);
        imb03= findViewById(R.id.imageButton4);
        imb04= findViewById(R.id.imageButton5);
        imb05= findViewById(R.id.imageButton6);
        imb06= findViewById(R.id.imageButton7);
        imb07= findViewById(R.id.imageButton8);
        imb08= findViewById(R.id.imageButton9);
        imb09= findViewById(R.id.imageButton10);
        imb10= findViewById(R.id.imageButton11);
        imb11= findViewById(R.id.imageButton12);


        listaBotones[0]=imb00;
        listaBotones[1]=imb01;
        listaBotones[2]=imb02;
        listaBotones[3]=imb03;
        listaBotones[4]=imb04;
        listaBotones[5]=imb05;
        listaBotones[6]=imb06;
        listaBotones[7]=imb07;
        listaBotones[8]=imb08;
        listaBotones[9]=imb09;
        listaBotones[10]=imb10;
        listaBotones[11]=imb11;
    }

    private void imagenes(){
        imagenes = new int[]{
                R.drawable.cerdo,
                R.drawable.dialga,
                R.drawable.osawod,
                R.drawable.palkia,
                R.drawable.snevy,
                R.drawable.elegante
        };
    }

    private ArrayList<Integer> barajar(int longitud){
        ArrayList resultadoA = new ArrayList<Integer>();
        for(int i=0; i<longitud*2; i++)
            resultadoA.add(i % longitud);
        Collections.shuffle(resultadoA);
        return  resultadoA;
    }

    private void comprobar(int i, final ImageButton imgb){


        if(primero == null){
            primero = imgb;
            primero.setScaleType(ImageView.ScaleType.CENTER_CROP);
            primero.setImageResource(imagenes[arrayDesordenar.get(i)]);
            primero.setEnabled(false);
            numPrimero = arrayDesordenar.get(i);
        } else {
            bloqueo = true;
            imgb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imgb.setImageResource(imagenes[arrayDesordenar.get(i)]);
            imgb.setEnabled(false);
            numSegundo = arrayDesordenar.get(i);
            if(numPrimero == numSegundo){
                puntuacion++;
                primero = null;
                bloqueo = false;
                aciertos++;
                punt=String.valueOf(puntuacion);
                pnt.setText(punt);
                if(aciertos == imagenes.length){
                    Toast toast = Toast.makeText(getApplicationContext(), "Has ganado!!", Toast.LENGTH_LONG);
                    toast.show();
                    punt=String.valueOf(puntuacion);
                    pnt.setText(punt);
                }
            } else {
                //puntuacion--;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        primero.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        primero.setImageResource(R.drawable.reverso);
                        primero.setEnabled(true);
                        imgb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        imgb.setImageResource(R.drawable.reverso);
                        imgb.setEnabled(true);
                        bloqueo = false;
                        primero = null;

                    }
                }, 1000);
            }
        }
    }

    private void init(){

        Juego();
        imagenes();
        barajar(imagenes.length);
        arrayDesordenar=barajar(imagenes.length);
        for (int i=0;i<listaBotones.length;i++){
            listaBotones[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
            listaBotones[i].setImageResource(imagenes[arrayDesordenar.get(i)]);
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (int i=0;i<listaBotones.length;i++){
                    listaBotones[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
                    listaBotones[i].setImageResource(R.drawable.reverso);
                }
            }
        },1500);
        for (int i=0;i<listaBotones.length;i++){
            final int j=i;
            listaBotones[i].setEnabled(true);
            listaBotones[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mediaPlayer.start();
                    if(!bloqueo){
                        comprobar(j,listaBotones[j]);
                    }
                }
            });
        }
    }


    public void Reiniciar(View view) {
        init();puntuacion=0; punt=String.valueOf(puntuacion); pnt.setText(punt);
    }
}